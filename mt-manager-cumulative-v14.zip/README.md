# MT Manager Cumulative v5

Kotlin Android project featuring a dual-pane file explorer, text editor, ZIP mounting and updating, archive creation, conflict handling, file properties, rename/create/jump dialogs, history navigation, and in-session English/Arabic locale switching.

## Build

Requirements: JDK 17, Android SDK platform 35, and network access on the first build to download Gradle 8.9 and Android dependencies.

```sh
./gradlew assembleDebug
```

The included shell launcher downloads Gradle 8.9 into the user's Gradle cache when needed. The standard Gradle wrapper JAR is not included; the launcher is a standalone downloader/launcher.


## v6-fixed cumulative changes

This package retains the complete v5 source tree and adds multi-selection state and controls, recursive deletion through the repository, delete confirmation, share/open actions, conflict-choice radio controls, and configurable ZIP entry name/source deletion options. The original repository, editor, manifest, resources, Gradle files, and separate UI/domain files remain present.

Build validation was attempted in the current environment but could not complete because the Gradle wrapper could not resolve `services.gradle.org`; therefore this archive is not represented as successfully compiled or runtime-tested.
