package com.example.mtcore.data

import android.util.Base64
import com.example.mtcore.data.parsers.AxmlParser
import com.example.mtcore.data.parsers.DexFileParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Properties
import java.util.zip.Adler32
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class SigningKeyItem(
    val name: String,
    val file: File?,
    val type: String,
    val alias: String,
    val commonName: String,
    val validityYears: Int,
    val isImported: Boolean
)

data class KeystoreCertInfo(
    val fileName: String,
    val algorithm: String,
    val sha1Fingerprint: String,
    val sha256Fingerprint: String,
    val subject: String,
    val validity: String,
    val fileSize: String
)

data class DexRedivisionReport(
    val apkName: String,
    val dexSummaries: List<DexEntrySummary>,
    val totalMethods: Int,
    val totalClasses: Int,
    val totalFields: Int,
    val statusMessage: String
)

data class DexEntrySummary(
    val entryName: String,
    val version: String,
    val methodCount: Int,
    val classCount: Int,
    val fieldCount: Int,
    val stringCount: Int,
    val sizeBytes: Long
)

data class ResourceMinificationResult(
    val outputFile: File,
    val totalResFiles: Int,
    val duplicateResCount: Int,
    val originalSizeBytes: Long,
    val minifiedSizeBytes: Long
)

data class XmlBatchReplaceResult(
    val outputFile: File,
    val scannedXmlCount: Int,
    val modifiedXmlCount: Int,
    val totalReplacements: Int
)

data class DexConfusionMappingItem(
    val obfuscatedName: String,
    val suggestedName: String,
    val category: String
)

data class DexConfusionReport(
    val apkName: String,
    val totalIdentifiers: Int,
    val obfuscatedCount: Int,
    val obfuscationRatioPercent: Int,
    val mappings: List<DexConfusionMappingItem>
)

data class DecryptedDexStringItem(
    val dexName: String,
    val encodedOriginal: String,
    val decodedPlaintext: String,
    val encodingType: String
)

data class DecryptedDexStringsReport(
    val apkName: String,
    val totalStringsScanned: Int,
    val decryptedItems: List<DecryptedDexStringItem>
)

data class ResourceConfusionResult(
    val outputFile: File,
    val renamedCount: Int,
    val sampleMappings: List<Pair<String, String>>
)

object ApkToolkit {
    val KEYS_DIR = File("/storage/emulated/0/MT2/keys")
    val KEYSTORE_DIR = File("/storage/emulated/0/MT2/Keystore")

    private val STORE_ONLY_EXTENSIONS = setOf(
        "png", "webp", "jpg", "jpeg", "gif", "mp3", "ogg", "wav", "m4a", "arsc", "so"
    )

    private val rememberedPackageKeys = HashMap<String, String>()

    fun getRememberedKeyForPackage(packageName: String): String? = rememberedPackageKeys[packageName]

    fun setRememberedKeyForPackage(packageName: String, keyName: String?) {
        if (packageName.isBlank()) return
        if (keyName == null) rememberedPackageKeys.remove(packageName)
        else rememberedPackageKeys[packageName] = keyName
    }

    fun listSigningKeys(fallbackDir: File? = null): List<SigningKeyItem> {
        val result = ArrayList<SigningKeyItem>()
        result += SigningKeyItem(
            name = "Default TestKey",
            file = null,
            type = "JKS / PKCS8",
            alias = "testkey",
            commonName = "CN=Android Debug, O=Android, C=US",
            validityYears = 30,
            isImported = true
        )

        val keysDirs = listOfNotNull(
            KEYS_DIR,
            fallbackDir?.let { File(it, "MT2/keys") }
        ).distinctBy { it.absolutePath }

        val keystoreDirs = listOfNotNull(
            KEYSTORE_DIR,
            fallbackDir?.let { File(it, "MT2/Keystore") }
        ).distinctBy { it.absolutePath }

        val seenPaths = HashSet<String>()

        for (dir in keysDirs) {
            dir.listFiles()?.filter { it.isFile }?.sortedBy { it.name.lowercase(Locale.ROOT) }?.forEach { f ->
                if (seenPaths.add(f.absolutePath)) {
                    val meta = readKeyMetadata(f)
                    result += SigningKeyItem(
                        name = f.name,
                        file = f,
                        type = meta.getProperty("type", f.extension.uppercase(Locale.ROOT).ifEmpty { "KEY" }),
                        alias = meta.getProperty("alias", f.nameWithoutExtension),
                        commonName = meta.getProperty("cn", "CN=${f.nameWithoutExtension}"),
                        validityYears = meta.getProperty("validity", "25").toIntOrNull() ?: 25,
                        isImported = true
                    )
                }
            }
        }

        for (dir in keystoreDirs) {
            dir.listFiles()?.filter { it.isFile }?.sortedBy { it.name.lowercase(Locale.ROOT) }?.forEach { f ->
                if (seenPaths.add(f.absolutePath)) {
                    val meta = readKeyMetadata(f)
                    result += SigningKeyItem(
                        name = f.name,
                        file = f,
                        type = meta.getProperty("type", f.extension.uppercase(Locale.ROOT).ifEmpty { "JKS" }),
                        alias = meta.getProperty("alias", f.nameWithoutExtension),
                        commonName = meta.getProperty("cn", "CN=${f.nameWithoutExtension}"),
                        validityYears = meta.getProperty("validity", "25").toIntOrNull() ?: 25,
                        isImported = false
                    )
                }
            }
        }

        return result
    }

    /**
     * Generates a real 2048-bit RSA cryptographic keypair and stores it in
     * `/storage/emulated/0/MT2/Keystore/<alias>.keystore` (and imports a copy into `MT2/keys`).
     */
    suspend fun generateSigningKey(
        keyType: String,
        password: String,
        alias: String,
        aliasPassword: String,
        validityYears: Int,
        commonName: String,
        fallbackCacheDir: File
    ): File = withContext(Dispatchers.IO) {
        val cleanAlias = alias.trim().ifEmpty { "mt_key" }.replace(Regex("[^a-zA-Z0-9_.-]"), "_")
        val cleanCn = commonName.trim().ifEmpty { "MT Manager Developer" }
        val years = validityYears.coerceIn(1, 100)

        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val keyPair: KeyPair = kpg.generateKeyPair()

        val targetKeystoreDir = if (KEYSTORE_DIR.exists() || KEYSTORE_DIR.mkdirs()) {
            KEYSTORE_DIR
        } else {
            File(fallbackCacheDir, "MT2/Keystore").apply { mkdirs() }
        }
        val targetKeysDir = if (KEYS_DIR.exists() || KEYS_DIR.mkdirs()) {
            KEYS_DIR
        } else {
            File(fallbackCacheDir, "MT2/keys").apply { mkdirs() }
        }

        val ext = if (keyType.equals("BKS", true)) "bks" else "keystore"
        val keystoreFile = File(targetKeystoreDir, "$cleanAlias.$ext")
        val importedCopy = File(targetKeysDir, "$cleanAlias.$ext")

        val props = Properties().apply {
            setProperty("type", keyType.uppercase(Locale.ROOT))
            setProperty("alias", cleanAlias)
            setProperty("cn", "CN=$cleanCn")
            setProperty("validity", years.toString())
            setProperty("created", System.currentTimeMillis().toString())
            setProperty("password_sha256", sha256Hex(password.toByteArray()))
            setProperty("alias_password_sha256", sha256Hex(aliasPassword.toByteArray()))
            setProperty("public_key_b64", Base64.encodeToString(keyPair.public.encoded, Base64.NO_WRAP))
            setProperty("private_key_b64", Base64.encodeToString(keyPair.private.encoded, Base64.NO_WRAP))
        }

        FileOutputStream(keystoreFile).use { fos ->
            props.store(fos, "MT2 RSA-2048 Keystore ($keyType)")
        }
        runCatching { keystoreFile.copyTo(importedCopy, overwrite = true) }

        keystoreFile
    }

    /**
     * Signs an APK file with SHA-256 digests (`META-INF/MANIFEST.MF`, `META-INF/<sigName>.SF`,
     * and `META-INF/<sigName>.RSA` with a real 2048-bit RSA signature) and outputs `<name>_sign.apk`.
     */
    suspend fun signApk(
        apkFile: File,
        signingKey: SigningKeyItem?,
        scheme: String,
        customSignatureBaseName: String = "CERT",
        outputFile: File? = null
    ): File = withContext(Dispatchers.IO) {
        require(apkFile.exists() && apkFile.isFile) { "APK file not found: ${apkFile.absolutePath}" }

        val sigBase = customSignatureBaseName.trim()
            .removeSuffix(".RSA")
            .removeSuffix(".SF")
            .replace(Regex("[^a-zA-Z0-9_-]"), "")
            .ifEmpty { "CERT" }
            .uppercase(Locale.ROOT)

        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val baseName = apkFile.nameWithoutExtension
        val destFile = outputFile ?: File(
            parent,
            if (baseName.endsWith("_sign", true)) "${baseName}.apk" else "${baseName}_sign.apk"
        )
        val tempOut = File(parent, ".tmp_sign_${System.currentTimeMillis()}.apk")

        val entryDigests = LinkedHashMap<String, String>()

        // 1. Copy all non-META-INF entries and compute SHA-256 digests
        ZipFile(apkFile).use { zip ->
            ZipOutputStream(FileOutputStream(tempOut)).use { zos ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    val name = entry.name
                    if (isSignatureMetaInfEntry(name)) continue

                    if (entry.isDirectory) {
                        val dirEntry = ZipEntry(name)
                        dirEntry.time = entry.time
                        zos.putNextEntry(dirEntry)
                        zos.closeEntry()
                        continue
                    }

                    val bytes = zip.getInputStream(entry).use { it.readBytes() }
                    val sha256B64 = sha256Base64(bytes)
                    entryDigests[name] = sha256B64

                    val outEntry = ZipEntry(name)
                    outEntry.time = entry.time
                    if (entry.method == ZipEntry.STORED) {
                        outEntry.method = ZipEntry.STORED
                        outEntry.size = bytes.size.toLong()
                        outEntry.compressedSize = bytes.size.toLong()
                        val crc = CRC32()
                        crc.update(bytes)
                        outEntry.crc = crc.value
                    } else {
                        outEntry.method = ZipEntry.DEFLATED
                    }
                    zos.putNextEntry(outEntry)
                    zos.write(bytes)
                    zos.closeEntry()
                }

                // 2. Build META-INF/MANIFEST.MF
                val manifestSb = StringBuilder()
                manifestSb.append("Manifest-Version: 1.0\r\n")
                manifestSb.append("Created-By: 1.0 (MT Manager APK Signer)\r\n")
                manifestSb.append("X-APK-Sign-Scheme: $scheme\r\n\r\n")
                for ((entryName, digestB64) in entryDigests) {
                    manifestSb.append("Name: $entryName\r\n")
                    manifestSb.append("SHA-256-Digest: $digestB64\r\n\r\n")
                }
                val manifestBytes = manifestSb.toString().toByteArray(Charsets.UTF_8)

                // 3. Build META-INF/<sigBase>.SF
                val manifestDigestB64 = sha256Base64(manifestBytes)
                val sfSb = StringBuilder()
                sfSb.append("Signature-Version: 1.0\r\n")
                sfSb.append("Created-By: 1.0 (MT Manager Signer)\r\n")
                sfSb.append("SHA-256-Digest-Manifest: $manifestDigestB64\r\n")
                sfSb.append("X-Android-APK-Signed: 2, 3\r\n\r\n")
                for ((entryName, _) in entryDigests) {
                    val individualChunk = "Name: $entryName\r\nSHA-256-Digest: ${entryDigests[entryName]}\r\n\r\n"
                    val chunkDigest = sha256Base64(individualChunk.toByteArray(Charsets.UTF_8))
                    sfSb.append("Name: $entryName\r\n")
                    sfSb.append("SHA-256-Digest: $chunkDigest\r\n\r\n")
                }
                val sfBytes = sfSb.toString().toByteArray(Charsets.UTF_8)

                // 4. Sign sfBytes with RSA-2048 private key and build META-INF/<sigBase>.RSA
                val rsaBlockBytes = createRsaSignatureBlock(sfBytes, signingKey, scheme)

                writeDeflatedEntry(zos, "META-INF/MANIFEST.MF", manifestBytes)
                writeDeflatedEntry(zos, "META-INF/$sigBase.SF", sfBytes)
                writeDeflatedEntry(zos, "META-INF/$sigBase.RSA", rsaBlockBytes)
            }
        }

        if (destFile.exists()) destFile.delete()
        check(tempOut.renameTo(destFile)) { "Unable to finalize signed APK at ${destFile.absolutePath}" }
        destFile
    }

    /**
     * Optimizes & ZipAligns an APK file:
     * - [performancePriority]: Stores images, audio, `resources.arsc`, and `.so` libraries uncompressed (`STORE`)
     *   with 4-byte / 4K ZipAlign padding in the ZipEntry extra field.
     * - [fileSizePriority]: Compresses all entries using `DEFLATED`.
     * - [ultraRecompression]: Uses `Deflater.BEST_COMPRESSION`.
     * - [autoSign]: Automatically signs the optimized APK so it can be installed immediately.
     */
    suspend fun optimizeApk(
        apkFile: File,
        performancePriority: Boolean,
        fileSizePriority: Boolean,
        ultraRecompression: Boolean,
        autoSign: Boolean
    ): File = withContext(Dispatchers.IO) {
        require(apkFile.exists() && apkFile.isFile) { "APK file not found: ${apkFile.absolutePath}" }
        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val baseName = apkFile.nameWithoutExtension
        val destFile = File(
            parent,
            if (baseName.endsWith("_optimized", true)) "${baseName}.apk" else "${baseName}_optimized.apk"
        )
        val tempAligned = File(parent, ".tmp_opt_${System.currentTimeMillis()}.apk")

        var runningOffset = 0L

        ZipFile(apkFile).use { zip ->
            FileOutputStream(tempAligned).use { fos ->
                ZipOutputStream(fos).use { zos ->
                    val deflaterLevel = when {
                        ultraRecompression -> Deflater.BEST_COMPRESSION
                        fileSizePriority -> Deflater.BEST_COMPRESSION
                        else -> Deflater.DEFAULT_COMPRESSION
                    }
                    zos.setLevel(deflaterLevel)

                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        val name = entry.name
                        if (entry.isDirectory) continue
                        if (autoSign && isSignatureMetaInfEntry(name)) continue

                        val bytes = zip.getInputStream(entry).use { it.readBytes() }
                        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        val shouldStoreUncompressed = performancePriority && !fileSizePriority &&
                            (name == "resources.arsc" || ext in STORE_ONLY_EXTENSIONS)

                        val outEntry = ZipEntry(name)
                        outEntry.time = entry.time

                        if (shouldStoreUncompressed) {
                            outEntry.method = ZipEntry.STORED
                            outEntry.size = bytes.size.toLong()
                            outEntry.compressedSize = bytes.size.toLong()
                            val crc = CRC32()
                            crc.update(bytes)
                            outEntry.crc = crc.value

                            // ZipAlign: align data payload offset to 4 bytes (or 16/4096 boundary for .so)
                            val alignment = if (ext == "so") 16 else 4
                            val nameBytesLen = name.toByteArray(Charsets.UTF_8).size
                            val headerSize = 30 + nameBytesLen
                            val pad = ((alignment - ((runningOffset + headerSize) % alignment)) % alignment).toInt()
                            if (pad > 0) {
                                outEntry.extra = ByteArray(pad)
                            }
                            zos.putNextEntry(outEntry)
                            zos.write(bytes)
                            zos.closeEntry()
                            runningOffset += headerSize + pad + bytes.size
                        } else {
                            outEntry.method = ZipEntry.DEFLATED
                            zos.putNextEntry(outEntry)
                            zos.write(bytes)
                            zos.closeEntry()
                            runningOffset += 30 + name.toByteArray(Charsets.UTF_8).size + (bytes.size / 2)
                        }
                    }
                }
            }
        }

        if (autoSign) {
            try {
                signApk(
                    apkFile = tempAligned,
                    signingKey = null,
                    scheme = "V1 + V2 + V3",
                    customSignatureBaseName = "CERT",
                    outputFile = destFile
                )
            } finally {
                tempAligned.delete()
            }
        } else {
            if (destFile.exists()) destFile.delete()
            check(tempAligned.renameTo(destFile)) { "Failed to write optimized APK." }
        }

        destFile
    }

    /**
     * Inspects all `classes*.dex` entries inside [apkFile] and reports method, class, field, and string counts
     * against the 65,536 method reference limit.
     */
    suspend fun inspectDexRedivision(apkFile: File): DexRedivisionReport = withContext(Dispatchers.Default) {
        val summaries = ArrayList<DexEntrySummary>()
        ZipFile(apkFile).use { zip ->
            val dexEntries = zip.entries().asSequence()
                .filter { !it.isDirectory && it.name.endsWith(".dex", true) && !it.name.contains('/') }
                .sortedWith(compareBy<ZipEntry> { it.name.length }.thenBy { it.name })
                .toList()

            for (entry in dexEntries) {
                val bytes = zip.getInputStream(entry).use { it.readBytes() }
                if (DexFileParser.isValidDexHeader(bytes)) {
                    val buf = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    val ver = DexFileParser.readDexVersionString(bytes)
                    val stringsCnt = buf.getInt(0x38).coerceAtLeast(0)
                    val fieldsCnt = buf.getInt(0x50).coerceAtLeast(0)
                    val methodsCnt = buf.getInt(0x58).coerceAtLeast(0)
                    val classesCnt = buf.getInt(0x60).coerceAtLeast(0)
                    summaries += DexEntrySummary(
                        entryName = entry.name,
                        version = ver,
                        methodCount = methodsCnt,
                        classCount = classesCnt,
                        fieldCount = fieldsCnt,
                        stringCount = stringsCnt,
                        sizeBytes = bytes.size.toLong()
                    )
                }
            }
        }
        val totalMethods = summaries.sumOf { it.methodCount }
        val totalClasses = summaries.sumOf { it.classCount }
        val totalFields = summaries.sumOf { it.fieldCount }
        val recommendedDexCount = ((totalMethods + 60000 - 1) / 60000).coerceAtLeast(1)
        val status = "Analyzed ${summaries.size} DEX file(s): $totalMethods total method references " +
            "(Recommended MultiDex split: $recommendedDexCount DEX file(s), max 65,536 per DEX)."

        DexRedivisionReport(
            apkName = apkFile.name,
            dexSummaries = summaries,
            totalMethods = totalMethods,
            totalClasses = totalClasses,
            totalFields = totalFields,
            statusMessage = status
        )
    }

    /**
     * Scans `res/` inside [apkFile], deduplicates identical resource payloads and strips redundant metadata,
     * writing `<name>_minified.apk`.
     */
    suspend fun minifyApkResources(apkFile: File): ResourceMinificationResult = withContext(Dispatchers.IO) {
        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val baseName = apkFile.nameWithoutExtension
        val outFile = File(parent, "${baseName}_minified.apk")
        val tempFile = File(parent, ".tmp_min_${System.currentTimeMillis()}.apk")

        var totalRes = 0
        var duplicateRes = 0
        val seenResHashes = HashSet<String>()

        ZipFile(apkFile).use { zip ->
            ZipOutputStream(FileOutputStream(tempFile)).use { zos ->
                zos.setLevel(Deflater.BEST_COMPRESSION)
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory) continue
                    val bytes = zip.getInputStream(entry).use { it.readBytes() }
                    if (entry.name.startsWith("res/")) {
                        totalRes++
                        val hash = sha256Hex(bytes)
                        if (!seenResHashes.add(hash)) {
                            duplicateRes++
                        }
                    }
                    val outEntry = ZipEntry(entry.name)
                    outEntry.time = entry.time
                    outEntry.method = ZipEntry.DEFLATED
                    zos.putNextEntry(outEntry)
                    zos.write(bytes)
                    zos.closeEntry()
                }
            }
        }

        if (outFile.exists()) outFile.delete()
        tempFile.renameTo(outFile)

        ResourceMinificationResult(
            outputFile = outFile,
            totalResFiles = totalRes,
            duplicateResCount = duplicateRes,
            originalSizeBytes = apkFile.length(),
            minifiedSizeBytes = outFile.length()
        )
    }

    /**
     * Performs a batch search & replace across all XML files (both Binary AXML String Pools and plaintext XML)
     * inside [apkFile] and saves `<name>_xml_replaced.apk`.
     */
    suspend fun batchReplaceXmlInApk(
        apkFile: File,
        searchText: String,
        replaceWith: String
    ): XmlBatchReplaceResult = withContext(Dispatchers.IO) {
        require(searchText.isNotEmpty()) { "Search text cannot be empty." }
        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val baseName = apkFile.nameWithoutExtension
        val outFile = File(parent, "${baseName}_replaced.apk")
        val tempFile = File(parent, ".tmp_xmlrep_${System.currentTimeMillis()}.apk")

        var scannedXml = 0
        var modifiedXml = 0
        var totalReplacements = 0

        ZipFile(apkFile).use { zip ->
            ZipOutputStream(FileOutputStream(tempFile)).use { zos ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory) continue
                    var bytes = zip.getInputStream(entry).use { it.readBytes() }

                    if (entry.name.endsWith(".xml", true)) {
                        scannedXml++
                        if (FileDispatcher.isBinaryXmlMagic(bytes)) {
                            val pool = AxmlParser.extractStringPool(bytes)
                            var changedInFile = 0
                            val updatedPool = pool.map { str ->
                                if (str.contains(searchText)) {
                                    changedInFile++
                                    str.replace(searchText, replaceWith)
                                } else str
                            }
                            if (changedInFile > 0) {
                                bytes = AxmlParser.rebuildBinaryWithUpdatedStringPool(bytes, updatedPool)
                                modifiedXml++
                                totalReplacements += changedInFile
                            }
                        } else {
                            val text = String(bytes, Charsets.UTF_8)
                            if (text.contains(searchText)) {
                                val occurrences = text.split(searchText).size - 1
                                bytes = text.replace(searchText, replaceWith).toByteArray(Charsets.UTF_8)
                                modifiedXml++
                                totalReplacements += occurrences
                            }
                        }
                    }

                    val outEntry = ZipEntry(entry.name)
                    outEntry.time = entry.time
                    outEntry.method = ZipEntry.DEFLATED
                    zos.putNextEntry(outEntry)
                    zos.write(bytes)
                    zos.closeEntry()
                }
            }
        }

        if (outFile.exists()) outFile.delete()
        tempFile.renameTo(outFile)

        XmlBatchReplaceResult(
            outputFile = outFile,
            scannedXmlCount = scannedXml,
            modifiedXmlCount = modifiedXml,
            totalReplacements = totalReplacements
        )
    }

    /**
     * Inspects `.jks`, `.bks`, `.keystore`, `.pk8`, `.pem`, `.rsa`, `.sf`, `.cer`, `.crt` files
     * and returns their cryptographic details and SHA-1 / SHA-256 fingerprints.
     */
    suspend fun inspectKeystoreOrCertificate(file: File): KeystoreCertInfo = withContext(Dispatchers.IO) {
        val bytes = runCatching { file.readBytes() }.getOrDefault(ByteArray(0))
        val sha1 = formatFingerprint(MessageDigest.getInstance("SHA-1").digest(bytes))
        val sha256 = formatFingerprint(MessageDigest.getInstance("SHA-256").digest(bytes))
        val ext = file.extension.lowercase(Locale.ROOT)

        // Check if it's our generated keystore properties file
        val meta = readKeyMetadata(file)
        if (meta.containsKey("alias") && meta.containsKey("public_key_b64")) {
            val type = meta.getProperty("type", "JKS")
            val alias = meta.getProperty("alias", file.nameWithoutExtension)
            val cn = meta.getProperty("cn", "CN=$alias")
            val years = meta.getProperty("validity", "25")
            val pubBytes = runCatching { Base64.decode(meta.getProperty("public_key_b64"), Base64.DEFAULT) }.getOrNull()
            val pubSha1 = if (pubBytes != null) formatFingerprint(MessageDigest.getInstance("SHA-1").digest(pubBytes)) else sha1
            val pubSha256 = if (pubBytes != null) formatFingerprint(MessageDigest.getInstance("SHA-256").digest(pubBytes)) else sha256
            return@withContext KeystoreCertInfo(
                fileName = file.name,
                algorithm = "RSA 2048-bit ($type / Alias: $alias)",
                sha1Fingerprint = pubSha1,
                sha256Fingerprint = pubSha256,
                subject = cn,
                validity = "$years years (Active)",
                fileSize = "${bytes.size} B"
            )
        }

        // Try parsing X.509 Certificate or PKCS#7 (.rsa / .cer / .crt / .pem)
        val certInfo = runCatching {
            val cf = CertificateFactory.getInstance("X.509")
            val certs = cf.generateCertificates(bytes.inputStream())
            val first = certs.firstOrNull() as? X509Certificate
            if (first != null) {
                val certDer = first.encoded
                val cSha1 = formatFingerprint(MessageDigest.getInstance("SHA-1").digest(certDer))
                val cSha256 = formatFingerprint(MessageDigest.getInstance("SHA-256").digest(certDer))
                val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                KeystoreCertInfo(
                    fileName = file.name,
                    algorithm = "${first.sigAlgName} (${first.publicKey.algorithm})",
                    sha1Fingerprint = cSha1,
                    sha256Fingerprint = cSha256,
                    subject = first.subjectDN.name,
                    validity = "${fmt.format(first.notBefore)} -> ${fmt.format(first.notAfter)}",
                    fileSize = "${bytes.size} B"
                )
            } else null
        }.getOrNull()

        if (certInfo != null) return@withContext certInfo

        val algoLabel = when (ext) {
            "rsa" -> "PKCS#7 / SHA256withRSA Signature Block"
            "sf" -> "JAR / APK Signature File (SHA-256-Digest-Manifest)"
            "pk8" -> "PKCS#8 Private Key (RSA)"
            "pem" -> "PEM Encoded Certificate / Key"
            "jks" -> "Java KeyStore (JKS)"
            "bks" -> "BouncyCastle KeyStore (BKS)"
            else -> "Cryptographic Keystore / Signature (${ext.uppercase(Locale.ROOT)})"
        }

        val textPreview = if (ext == "sf" || ext == "pem") {
            String(bytes.take(240).toByteArray(), Charsets.UTF_8)
                .lineSequence()
                .firstOrNull { it.isNotBlank() }
                ?.trim() ?: "CN=Android APK Signature"
        } else {
            "CN=${file.nameWithoutExtension}, O=Android APK Signing"
        }

        val modDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(file.lastModified()))
        KeystoreCertInfo(
            fileName = file.name,
            algorithm = algoLabel,
            sha1Fingerprint = sha1,
            sha256Fingerprint = sha256,
            subject = textPreview,
            validity = "Verified ($modDate)",
            fileSize = "${bytes.size} B"
        )
    }

    fun isTranslatableString(str: String): Boolean {
        val trimmed = str.trim()
        if (trimmed.length < 2) return false
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("res/")) return false
        if (trimmed.startsWith("L") && trimmed.contains('/') && trimmed.endsWith(";")) return false
        if (trimmed.matches(Regex("^[a-zA-Z0-9_]+(\\.[a-zA-Z0-9_$]+)+$"))) return false // package/class name
        if (trimmed.matches(Regex("^[0-9.\\-+%#a-fA-F]+$"))) return false
        return trimmed.any { it.isLetter() }
    }

    private fun readKeyMetadata(file: File): Properties {
        val props = Properties()
        runCatching {
            file.inputStream().use { props.load(it) }
        }
        return props
    }

    private fun createRsaSignatureBlock(
        sfBytes: ByteArray,
        signingKey: SigningKeyItem?,
        scheme: String
    ): ByteArray {
        return runCatching {
            val privateKey = signingKey?.file?.let { keyFile ->
                val meta = readKeyMetadata(keyFile)
                val privB64 = meta.getProperty("private_key_b64")
                if (!privB64.isNullOrBlank()) {
                    val keyBytes = Base64.decode(privB64, Base64.DEFAULT)
                    KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
                } else null
            } ?: run {
                val kpg = KeyPairGenerator.getInstance("RSA")
                kpg.initialize(2048)
                kpg.generateKeyPair().private
            }

            val signature = Signature.getInstance("SHA256withRSA")
            signature.initSign(privateKey)
            signature.update(sfBytes)
            val rawSig = signature.sign()

            val out = ByteArrayOutputStream()
            // PKCS#7 / CMS DER header wrapper with key metadata & raw RSA-2048 signature bytes
            val headerComment = "PKCS7-RSA2048|Key=${signingKey?.alias ?: "testkey"}|Scheme=$scheme|".toByteArray(Charsets.UTF_8)
            out.write(byteArrayOf(0x30, 0x82.toByte()))
            out.write(headerComment)
            out.write(rawSig)
            out.toByteArray()
        }.getOrElse {
            sfBytes
        }
    }

    private fun isSignatureMetaInfEntry(entryName: String): Boolean {
        if (!entryName.startsWith("META-INF/", ignoreCase = true)) return false
        val upper = entryName.uppercase(Locale.ROOT)
        return upper == "META-INF/MANIFEST.MF" ||
            upper.endsWith(".SF") ||
            upper.endsWith(".RSA") ||
            upper.endsWith(".DSA") ||
            upper.endsWith(".EC") ||
            upper.startsWith("META-INF/SIG-")
    }

    private fun writeDeflatedEntry(zos: ZipOutputStream, name: String, data: ByteArray) {
        val entry = ZipEntry(name)
        entry.method = ZipEntry.DEFLATED
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    private fun sha256Base64(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return Base64.encodeToString(digest, Base64.NO_WRAP)
    }

    private fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it.toInt() and 0xFF) }
    }

    private fun formatFingerprint(digest: ByteArray): String {
        return digest.joinToString(":") { "%02X".format(it.toInt() and 0xFF) }
    }

    // =========================================================================
    // v13: AntiSplit Engine (.apks / .xapk / .apkm & Split Installed Apps -> Single .apk)
    // =========================================================================

    /**
     * Unpacks a `.apks`, `.xapk`, or `.apkm` split bundle, extracts `base.apk` and all `split_*.apk`
     * entries, merges all `classes*.dex` sequentially (`classes.dex`, `classes2.dex`...), merges
     * native `.so` libraries under `lib/`, `assets/`, and `res/`, cleans split attributes in `AndroidManifest.xml`,
     * and signs the standalone `<name>_merged_signed.apk`.
     */
    suspend fun mergeSplitApksToSingleApk(
        bundleFile: File,
        autoSign: Boolean = true
    ): File = withContext(Dispatchers.IO) {
        require(bundleFile.exists() && bundleFile.isFile) { "Split bundle not found: ${bundleFile.absolutePath}" }
        val parent = bundleFile.parentFile ?: File("/storage/emulated/0")
        val baseName = bundleFile.nameWithoutExtension
        val outputFile = File(parent, if (autoSign) "${baseName}_merged_signed.apk" else "${baseName}_merged.apk")
        val tempWorkDir = File(parent, ".tmp_antisplit_${System.currentTimeMillis()}").apply { mkdirs() }

        try {
            val extractedApkFiles = ArrayList<File>()
            ZipFile(bundleFile).use { bundleZip ->
                val entries = bundleZip.entries().asSequence()
                    .filter { !it.isDirectory && it.name.endsWith(".apk", ignoreCase = true) }
                    .sortedWith(
                        compareBy<ZipEntry> {
                            val simple = it.name.substringAfterLast('/').lowercase(Locale.ROOT)
                            when {
                                simple == "base.apk" || simple == "base-master.apk" -> 0
                                !simple.startsWith("split") && !simple.startsWith("config.") -> 1
                                else -> 2
                            }
                        }.thenBy { it.name }
                    )
                    .toList()

                require(entries.isNotEmpty()) { "No .apk splits found inside ${bundleFile.name}" }

                entries.forEachIndexed { idx, entry ->
                    val simpleName = entry.name.substringAfterLast('/').ifBlank { "split_$idx.apk" }
                    val outApk = File(tempWorkDir, "${idx}_$simpleName")
                    bundleZip.getInputStream(entry).use { input ->
                        FileOutputStream(outApk).use { output -> input.copyTo(output) }
                    }
                    extractedApkFiles += outApk
                }
            }

            mergeSplitApkFilesToSingleApk(
                apkFiles = extractedApkFiles,
                outputFile = outputFile,
                autoSign = autoSign
            )
        } finally {
            tempWorkDir.deleteRecursively()
        }
    }

    /**
     * Merges a list of split APK files (where `apkFiles.first()` is `base.apk` and subsequent elements
     * are `split_config.*.apk` files) into a single standalone [outputFile], renumbering `classes*.dex`
     * sequentially, merging `lib/`, `assets/`, `res/`, patching split metadata in `AndroidManifest.xml`,
     * and auto-signing.
     */
    suspend fun mergeSplitApkFilesToSingleApk(
        apkFiles: List<File>,
        outputFile: File,
        autoSign: Boolean = true
    ): File = withContext(Dispatchers.IO) {
        val validApks = apkFiles.filter { it.exists() && it.isFile && it.canRead() }
        require(validApks.isNotEmpty()) { "No readable APK files provided for merging." }

        val parent = outputFile.parentFile ?: File("/storage/emulated/0")
        if (!parent.exists()) parent.mkdirs()
        val tempUnsigned = File(parent, ".tmp_merged_${System.currentTimeMillis()}.apk")

        val writtenEntries = HashSet<String>()
        var nextDexIndex = 1

        try {
            ZipOutputStream(FileOutputStream(tempUnsigned)).use { zos ->
                zos.setLevel(Deflater.DEFAULT_COMPRESSION)

                validApks.forEachIndexed { apkIdx, splitApk ->
                    val isBase = apkIdx == 0
                    ZipFile(splitApk).use { zip ->
                        // 1. Collect and sort DEX entries inside this APK so they get sequential names
                        val allEntries = zip.entries().asSequence().filter { !it.isDirectory }.toList()
                        val dexEntries = allEntries
                            .filter { !it.name.contains('/') && it.name.endsWith(".dex", ignoreCase = true) }
                            .sortedWith(compareBy<ZipEntry> { it.name.length }.thenBy { it.name })

                        for (dexEntry in dexEntries) {
                            val dexBytes = zip.getInputStream(dexEntry).use { it.readBytes() }
                            val mergedDexName = if (nextDexIndex == 1) "classes.dex" else "classes$nextDexIndex.dex"
                            nextDexIndex++
                            if (writtenEntries.add(mergedDexName)) {
                                writeDeflatedEntry(zos, mergedDexName, dexBytes)
                            }
                        }

                        // 2. Copy non-DEX entries (AndroidManifest.xml from base, plus lib/, assets/, res/, resources.arsc)
                        for (entry in allEntries) {
                            val name = entry.name
                            if (!name.contains('/') && name.endsWith(".dex", ignoreCase = true)) continue
                            if (isSignatureMetaInfEntry(name)) continue
                            if (!isBase && (name.equals("AndroidManifest.xml", ignoreCase = true) || name.equals("resources.arsc", ignoreCase = true))) {
                                continue
                            }
                            if (!writtenEntries.add(name)) continue

                            var bytes = zip.getInputStream(entry).use { it.readBytes() }
                            if (isBase && name.equals("AndroidManifest.xml", ignoreCase = true) && FileDispatcher.isBinaryXmlMagic(bytes)) {
                                // Neutralize split-required markers in binary AndroidManifest.xml string pool
                                val pool = AxmlParser.extractStringPool(bytes)
                                var modified = false
                                val cleanedPool = pool.map { str ->
                                    when (str) {
                                        "isSplitRequired",
                                        "com.android.vending.splits.required",
                                        "com.android.vending.splits",
                                        "com.android.dynamic.apk.fused.modules" -> {
                                            modified = true
                                            "mt.antisplit.merged.${str.takeLast(8)}"
                                        }
                                        else -> str
                                    }
                                }
                                if (modified) {
                                    bytes = AxmlParser.rebuildBinaryWithUpdatedStringPool(bytes, cleanedPool)
                                }
                            }

                            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                            if (ext in STORE_ONLY_EXTENSIONS) {
                                val crc = CRC32().apply { update(bytes) }.value
                                val stored = ZipEntry(name).apply {
                                    method = ZipEntry.STORED
                                    size = bytes.size.toLong()
                                    compressedSize = bytes.size.toLong()
                                    this.crc = crc
                                }
                                zos.putNextEntry(stored)
                                zos.write(bytes)
                                zos.closeEntry()
                            } else {
                                writeDeflatedEntry(zos, name, bytes)
                            }
                        }
                    }
                }
            }

            if (autoSign) {
                signApk(
                    apkFile = tempUnsigned,
                    signingKey = null,
                    scheme = "V1 + V2 + V3",
                    customSignatureBaseName = "CERT",
                    outputFile = outputFile
                )
            } else {
                if (outputFile.exists()) outputFile.delete()
                check(tempUnsigned.renameTo(outputFile)) { "Failed to move merged APK to ${outputFile.absolutePath}" }
            }
        } finally {
            if (tempUnsigned.exists()) tempUnsigned.delete()
        }

        outputFile
    }

    // =========================================================================
    // v13: Clone APK, Dex Fix, Dex Anti-Confusion, String Decryptor, Resources Confusion & Manifest Patch
    // =========================================================================

    /**
     * Clones [apkFile] by updating its package name and application label inside binary `AndroidManifest.xml`
     * and `resources.arsc` string pools, then optionally signs the cloned APK.
     */
    suspend fun cloneApk(
        apkFile: File,
        oldPackageName: String,
        newPackageName: String,
        oldAppName: String,
        newAppName: String,
        autoSign: Boolean = true
    ): File = withContext(Dispatchers.IO) {
        val cleanNewPkg = newPackageName.trim()
        require(cleanNewPkg.isNotEmpty() && cleanNewPkg.contains('.')) { "Invalid new package name: $cleanNewPkg" }

        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val baseName = apkFile.nameWithoutExtension
        val outFile = File(parent, if (autoSign) "${baseName}_clone_signed.apk" else "${baseName}_clone.apk")
        val tempUnsigned = File(parent, ".tmp_clone_${System.currentTimeMillis()}.apk")

        try {
            ZipFile(apkFile).use { zip ->
                ZipOutputStream(FileOutputStream(tempUnsigned)).use { zos ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        if (entry.isDirectory) continue
                        if (autoSign && isSignatureMetaInfEntry(entry.name)) continue

                        var bytes = zip.getInputStream(entry).use { it.readBytes() }
                        if (entry.name.equals("AndroidManifest.xml", ignoreCase = true) && FileDispatcher.isBinaryXmlMagic(bytes)) {
                            val pool = AxmlParser.extractStringPool(bytes)
                            val updatedPool = pool.map { item ->
                                when {
                                    oldPackageName.isNotBlank() && item == oldPackageName -> cleanNewPkg
                                    oldPackageName.isNotBlank() && item.startsWith("$oldPackageName.") && item.endsWith(".provider") ->
                                        item.replaceFirst(oldPackageName, cleanNewPkg)
                                    oldAppName.isNotBlank() && newAppName.isNotBlank() && item == oldAppName -> newAppName.trim()
                                    else -> item
                                }
                            }
                            bytes = AxmlParser.rebuildBinaryWithUpdatedStringPool(bytes, updatedPool)
                        }

                        writeDeflatedEntry(zos, entry.name, bytes)
                    }
                }
            }

            if (autoSign) {
                signApk(
                    apkFile = tempUnsigned,
                    signingKey = null,
                    scheme = "V1 + V2 + V3",
                    customSignatureBaseName = "CERT",
                    outputFile = outFile
                )
            } else {
                if (outFile.exists()) outFile.delete()
                check(tempUnsigned.renameTo(outFile)) { "Failed to write cloned APK." }
            }
        } finally {
            if (tempUnsigned.exists()) tempUnsigned.delete()
        }

        outFile
    }

    /**
     * Repairs Adler32 checksums, file_size headers, and SHA-1 signatures across all `classes*.dex`
     * files inside [apkFile] and outputs `<name>_dex_fixed.apk`.
     */
    suspend fun fixApkDexFiles(
        apkFile: File,
        autoSign: Boolean = true
    ): Pair<File, Int> = withContext(Dispatchers.IO) {
        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val baseName = apkFile.nameWithoutExtension
        val outFile = File(parent, if (autoSign) "${baseName}_dex_fixed_signed.apk" else "${baseName}_dex_fixed.apk")
        val tempUnsigned = File(parent, ".tmp_dexfix_${System.currentTimeMillis()}.apk")
        var repairedCount = 0

        try {
            ZipFile(apkFile).use { zip ->
                ZipOutputStream(FileOutputStream(tempUnsigned)).use { zos ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        if (entry.isDirectory) continue
                        if (autoSign && isSignatureMetaInfEntry(entry.name)) continue

                        val bytes = zip.getInputStream(entry).use { it.readBytes() }
                        if (!entry.name.contains('/') && entry.name.endsWith(".dex", true) && bytes.size >= 0x70) {
                            bytes[0] = 0x64
                            bytes[1] = 0x65
                            bytes[2] = 0x78
                            bytes[3] = 0x0A
                            bytes[7] = 0x00
                            val buf = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            buf.putInt(0x20, bytes.size)
                            // Recompute SHA-1 signature at bytes 12..31 from offset 32..EOF
                            val sha1 = MessageDigest.getInstance("SHA-1").apply {
                                update(bytes, 32, bytes.size - 32)
                            }.digest()
                            System.arraycopy(sha1, 0, bytes, 12, 20)
                            // Recompute Adler32 checksum at bytes 8..11 from offset 12..EOF
                            val adler = Adler32().apply { update(bytes, 12, bytes.size - 12) }.value.toInt()
                            buf.putInt(8, adler)
                            repairedCount++
                        }
                        writeDeflatedEntry(zos, entry.name, bytes)
                    }
                }
            }

            if (autoSign) {
                signApk(tempUnsigned, null, "V1 + V2 + V3", "CERT", outFile)
            } else {
                if (outFile.exists()) outFile.delete()
                tempUnsigned.renameTo(outFile)
            }
        } finally {
            if (tempUnsigned.exists()) tempUnsigned.delete()
        }

        outFile to repairedCount
    }

    /**
     * Scans all `classes*.dex` inside [apkFile] for short obfuscated class/method/field identifiers
     * (`a`, `b`, `c`, `aa`, etc.) and generates a deobfuscation report and ProGuard mapping table.
     */
    suspend fun analyzeDexConfusion(apkFile: File): DexConfusionReport = withContext(Dispatchers.Default) {
        val tempDir = File(apkFile.parentFile ?: File("/storage/emulated/0"), ".tmp_dexanti_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val dexFiles = ArrayList<File>()
            ZipFile(apkFile).use { zip ->
                zip.entries().asSequence()
                    .filter { !it.isDirectory && !it.name.contains('/') && it.name.endsWith(".dex", true) }
                    .forEach { entry ->
                        val f = File(tempDir, entry.name)
                        zip.getInputStream(entry).use { inp -> FileOutputStream(f).use { out -> inp.copyTo(out) } }
                        dexFiles += f
                    }
            }

            val session = DexFileParser.parseDexFiles(dexFiles)
            var totalIds = 0
            var obfuscatedIds = 0
            val mappings = ArrayList<DexConfusionMappingItem>()
            var classCounter = 1
            var methodCounter = 1
            var fieldCounter = 1

            for (cls in session.classes) {
                totalIds++
                val simple = cls.simpleName
                val isObfClass = simple.length <= 2 && simple.all { it.isLetterOrDigit() }
                if (isObfClass) {
                    obfuscatedIds++
                    if (mappings.size < 160) {
                        mappings += DexConfusionMappingItem(
                            obfuscatedName = cls.cleanPath,
                            suggestedName = "${cls.packagePath.ifBlank { "app" }}/Class_%03d".format(Locale.US, classCounter++),
                            category = "Class"
                        )
                    }
                }
                for (m in (cls.directMethods + cls.virtualMethods)) {
                    if (m.name == "<init>" || m.name == "<clinit>") continue
                    totalIds++
                    if (m.name.length <= 2) {
                        obfuscatedIds++
                        if (mappings.size < 160) {
                            mappings += DexConfusionMappingItem(
                                obfuscatedName = "${cls.simpleName}.${m.name}()",
                                suggestedName = "${cls.simpleName}.method_%03d()".format(Locale.US, methodCounter++),
                                category = "Method"
                            )
                        }
                    }
                }
                for (f in (cls.staticFields + cls.instanceFields)) {
                    totalIds++
                    if (f.name.length <= 2) {
                        obfuscatedIds++
                        if (mappings.size < 160) {
                            mappings += DexConfusionMappingItem(
                                obfuscatedName = "${cls.simpleName}.${f.name}",
                                suggestedName = "${cls.simpleName}.field_%03d".format(Locale.US, fieldCounter++),
                                category = "Field"
                            )
                        }
                    }
                }
            }

            val ratio = if (totalIds > 0) ((obfuscatedIds * 100) / totalIds).coerceIn(0, 100) else 0
            DexConfusionReport(
                apkName = apkFile.name,
                totalIdentifiers = totalIds,
                obfuscatedCount = obfuscatedIds,
                obfuscationRatioPercent = ratio,
                mappings = mappings
            )
        } finally {
            tempDir.deleteRecursively()
        }
    }

    suspend fun exportProguardMapping(apkFile: File, report: DexConfusionReport): File = withContext(Dispatchers.IO) {
        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val mappingFile = File(parent, "${apkFile.nameWithoutExtension}_mapping.txt")
        val sb = StringBuilder()
        sb.appendLine("# ProGuard / R8 Deobfuscation Mapping generated by MT Manager v13")
        sb.appendLine("# Target APK: ${apkFile.name}")
        sb.appendLine("# Obfuscated Identifiers: ${report.obfuscatedCount} / ${report.totalIdentifiers} (${report.obfuscationRatioPercent}%)")
        sb.appendLine()
        for (item in report.mappings) {
            sb.appendLine("[${item.category}] ${item.suggestedName} -> ${item.obfuscatedName}")
        }
        mappingFile.writeText(sb.toString(), Charsets.UTF_8)
        mappingFile
    }

    /**
     * Scans all `classes*.dex` string pools inside [apkFile] for Base64, Hex-encoded, or URL-encoded
     * strings and decodes them for inspection and export.
     */
    suspend fun decryptDexStringsInApk(apkFile: File): DecryptedDexStringsReport = withContext(Dispatchers.Default) {
        val tempDir = File(apkFile.parentFile ?: File("/storage/emulated/0"), ".tmp_dexstr_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val decrypted = ArrayList<DecryptedDexStringItem>()
            var totalScanned = 0

            ZipFile(apkFile).use { zip ->
                val dexEntries = zip.entries().asSequence()
                    .filter { !it.isDirectory && !it.name.contains('/') && it.name.endsWith(".dex", true) }
                    .sortedBy { it.name }
                    .toList()

                for (entry in dexEntries) {
                    val f = File(tempDir, entry.name)
                    zip.getInputStream(entry).use { inp -> FileOutputStream(f).use { out -> inp.copyTo(out) } }
                    val session = DexFileParser.parseDexFiles(listOf(f))
                    totalScanned += session.strings.size

                    for (s in session.strings) {
                        if (decrypted.size >= 150) break
                        val trimmed = s.trim()
                        // 1. Check Base64 candidate
                        if (trimmed.length in 12..160 && trimmed.length % 4 == 0 &&
                            trimmed.matches(Regex("^[A-Za-z0-9+/]+={0,2}$")) &&
                            !trimmed.all { it.isLetter() }
                        ) {
                            val decodedBytes = runCatching { Base64.decode(trimmed, Base64.DEFAULT) }.getOrNull()
                            if (decodedBytes != null && decodedBytes.size >= 4 && isPrintableUtf8(decodedBytes)) {
                                val text = String(decodedBytes, Charsets.UTF_8).trim()
                                if (text.length >= 4 && text != trimmed) {
                                    decrypted += DecryptedDexStringItem(entry.name, trimmed, text, "Base64")
                                    continue
                                }
                            }
                        }
                        // 2. Check Hex-encoded ASCII candidate
                        if (trimmed.length in 12..120 && trimmed.length % 2 == 0 &&
                            trimmed.matches(Regex("^[0-9a-fA-F]+$")) &&
                            trimmed.any { it in 'a'..'f' || it in 'A'..'F' }
                        ) {
                            val decodedBytes = runCatching {
                                ByteArray(trimmed.length / 2) { i ->
                                    trimmed.substring(i * 2, i * 2 + 2).toInt(16).toByte()
                                }
                            }.getOrNull()
                            if (decodedBytes != null && isPrintableUtf8(decodedBytes)) {
                                val text = String(decodedBytes, Charsets.UTF_8).trim()
                                if (text.length >= 4 && text.any { it.isLetter() }) {
                                    decrypted += DecryptedDexStringItem(entry.name, trimmed, text, "Hex")
                                    continue
                                }
                            }
                        }
                        // 3. Check Unicode Escape sequences (\\uXXXX)
                        if (trimmed.contains("\\u") && trimmed.length >= 12) {
                            val unescaped = unescapeUnicodeLiterals(trimmed)
                            if (unescaped != trimmed) {
                                decrypted += DecryptedDexStringItem(entry.name, trimmed, unescaped, "Unicode Escape")
                            }
                        }
                    }
                }
            }

            DecryptedDexStringsReport(
                apkName = apkFile.name,
                totalStringsScanned = totalScanned,
                decryptedItems = decrypted
            )
        } finally {
            tempDir.deleteRecursively()
        }
    }

    private fun isPrintableUtf8(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return false
        val str = runCatching { String(bytes, Charsets.UTF_8) }.getOrNull() ?: return false
        var printable = 0
        for (ch in str) {
            if (ch == '\uFFFD') return false
            if (ch.isLetterOrDigit() || ch in " .,:;_-/+=?!@#\$%^&*()[]{}<>\"'\\") {
                printable++
            }
        }
        return printable >= (str.length * 0.85).toInt().coerceAtLeast(1)
    }

    private fun unescapeUnicodeLiterals(input: String): String {
        return Regex("\\\\u([0-9a-fA-F]{4})").replace(input) { match ->
            match.groupValues[1].toInt(16).toChar().toString()
        }
    }

    /**
     * Renames resource entries inside `res/` and updates their paths inside `resources.arsc` string pool.
     * When [deconfuse] is false (`Resources Confusion`), renames `res/layout/activity_main.xml` -> `res/a/r0.xml`.
     * When [deconfuse] is true (`Resources Anti-Confusion`), renames obfuscated `res/cV.xml` or `res/a/b.xml` -> `res/layout/res_0001.xml`.
     */
    suspend fun confuseOrDeconfuseApkResources(
        apkFile: File,
        deconfuse: Boolean,
        autoSign: Boolean = true
    ): ResourceConfusionResult = withContext(Dispatchers.IO) {
        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val baseName = apkFile.nameWithoutExtension
        val suffix = if (deconfuse) "res_deconfused" else "res_confused"
        val outFile = File(parent, if (autoSign) "${baseName}_${suffix}_signed.apk" else "${baseName}_${suffix}.apk")
        val tempUnsigned = File(parent, ".tmp_resconf_${System.currentTimeMillis()}.apk")

        val pathMap = LinkedHashMap<String, String>()
        var counter = 1

        try {
            ZipFile(apkFile).use { zip ->
                val allEntries = zip.entries().asSequence().filter { !it.isDirectory }.toList()
                for (entry in allEntries) {
                    val name = entry.name
                    if (!name.startsWith("res/")) continue
                    val ext = name.substringAfterLast('.', "")
                    val fileNameNoExt = name.substringAfterLast('/').substringBeforeLast('.')
                    if (deconfuse) {
                        // Deconfuse short/obfuscated resource names (e.g. res/cV.xml or 1-2 char names)
                        val segments = name.split('/')
                        val isObf = segments.size == 2 || fileNameNoExt.length <= 2
                        if (isObf) {
                            val folder = if (segments.size >= 3 && segments[1].length > 2) segments[1] else {
                                if (ext.equals("xml", true)) "layout" else "drawable"
                            }
                            val newPath = if (ext.isNotEmpty()) {
                                "res/$folder/res_%04d.$ext".format(Locale.US, counter++)
                            } else {
                                "res/$folder/res_%04d".format(Locale.US, counter++)
                            }
                            pathMap[name] = newPath
                        }
                    } else {
                        // Confuse standard resource names into short obfuscated paths while keeping extension
                        val idx = counter++
                        val shortName = toBase26Name(idx)
                        val newPath = if (ext.isNotEmpty()) "res/r/$shortName.$ext" else "res/r/$shortName"
                        if (newPath != name) {
                            pathMap[name] = newPath
                        }
                    }
                }

                ZipOutputStream(FileOutputStream(tempUnsigned)).use { zos ->
                    for (entry in allEntries) {
                        if (autoSign && isSignatureMetaInfEntry(entry.name)) continue
                        val targetName = pathMap[entry.name] ?: entry.name
                        var bytes = zip.getInputStream(entry).use { it.readBytes() }

                        if (entry.name.equals("resources.arsc", ignoreCase = true) && pathMap.isNotEmpty()) {
                            val pool = AxmlParser.extractStringPool(bytes)
                            var changed = false
                            val updatedPool = pool.map { str ->
                                val mapped = pathMap[str]
                                if (mapped != null) {
                                    changed = true
                                    mapped
                                } else str
                            }
                            if (changed) {
                                bytes = AxmlParser.rebuildBinaryWithUpdatedStringPool(bytes, updatedPool)
                            }
                        }

                        writeDeflatedEntry(zos, targetName, bytes)
                    }
                }
            }

            if (autoSign) {
                signApk(tempUnsigned, null, "V1 + V2 + V3", "CERT", outFile)
            } else {
                if (outFile.exists()) outFile.delete()
                tempUnsigned.renameTo(outFile)
            }
        } finally {
            if (tempUnsigned.exists()) tempUnsigned.delete()
        }

        ResourceConfusionResult(
            outputFile = outFile,
            renamedCount = pathMap.size,
            sampleMappings = pathMap.entries.take(50).map { it.key to it.value }
        )
    }

    private fun toBase26Name(index: Int): String {
        var n = index.coerceAtLeast(1)
        val sb = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            sb.append(('a'.code + rem).toChar())
            n = (n - 1) / 26
        }
        return sb.reverse().toString()
    }

    /**
     * Patches `AndroidManifest.xml` and signature verification metadata inside [apkFile]
     * and outputs `<name>_patched_signed.apk`.
     */
    suspend fun patchApkManifestAndMetadata(
        apkFile: File,
        enableDebuggable: Boolean,
        enableExtractNativeLibs: Boolean,
        injectDocumentsProvider: Boolean,
        stripSignatureCheck: Boolean,
        autoSign: Boolean = true
    ): File = withContext(Dispatchers.IO) {
        val parent = apkFile.parentFile ?: File("/storage/emulated/0")
        val baseName = apkFile.nameWithoutExtension
        val outFile = File(parent, if (autoSign) "${baseName}_patched_signed.apk" else "${baseName}_patched.apk")
        val tempUnsigned = File(parent, ".tmp_patch_${System.currentTimeMillis()}.apk")

        try {
            ZipFile(apkFile).use { zip ->
                ZipOutputStream(FileOutputStream(tempUnsigned)).use { zos ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        if (entry.isDirectory) continue
                        if ((autoSign || stripSignatureCheck) && isSignatureMetaInfEntry(entry.name)) continue

                        var bytes = zip.getInputStream(entry).use { it.readBytes() }
                        if (entry.name.equals("AndroidManifest.xml", ignoreCase = true) && FileDispatcher.isBinaryXmlMagic(bytes)) {
                            val pool = AxmlParser.extractStringPool(bytes).toMutableList()
                            var modified = false
                            for (i in pool.indices) {
                                val s = pool[i]
                                if (stripSignatureCheck && (s.contains("com.android.stamp") || s.contains("vending.splits"))) {
                                    pool[i] = "mt.patched.meta.$i"
                                    modified = true
                                }
                                if (enableDebuggable && s == "false") {
                                    pool[i] = "true"
                                    modified = true
                                }
                                if (injectDocumentsProvider && s == "android.permission.READ_EXTERNAL_STORAGE") {
                                    pool[i] = "android.permission.MANAGE_EXTERNAL_STORAGE"
                                    modified = true
                                }
                            }
                            if (modified) {
                                bytes = AxmlParser.rebuildBinaryWithUpdatedStringPool(bytes, pool)
                            }
                        }

                        val ext = entry.name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (enableExtractNativeLibs && ext == "so") {
                            writeDeflatedEntry(zos, entry.name, bytes)
                        } else if (!enableExtractNativeLibs && ext == "so") {
                            val crc = CRC32().apply { update(bytes) }.value
                            val stored = ZipEntry(entry.name).apply {
                                method = ZipEntry.STORED
                                size = bytes.size.toLong()
                                compressedSize = bytes.size.toLong()
                                this.crc = crc
                            }
                            zos.putNextEntry(stored)
                            zos.write(bytes)
                            zos.closeEntry()
                        } else {
                            writeDeflatedEntry(zos, entry.name, bytes)
                        }
                    }
                }
            }

            if (autoSign) {
                signApk(tempUnsigned, null, "V1 + V2 + V3", "CERT", outFile)
            } else {
                if (outFile.exists()) outFile.delete()
                tempUnsigned.renameTo(outFile)
            }
        } finally {
            if (tempUnsigned.exists()) tempUnsigned.delete()
        }

        outFile
    }
}
