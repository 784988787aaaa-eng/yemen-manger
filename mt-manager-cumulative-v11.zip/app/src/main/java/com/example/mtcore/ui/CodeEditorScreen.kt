package com.example.mtcore.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.mtcore.R
import kotlinx.coroutines.launch
import java.util.Locale

private val EditorToolbar = Color(0xFF2B2B2B)
private val EditorWhite = Color.White
private val LineNumberBackground = Color(0xFFF5F5F5)
private val EditorGray = Color(0xFF757575)
private val EditorSeparator = Color(0xFFE0E0E0)

private val ClassBadgeColor = Color(0xFF4285F4)
private val FieldBadgeColor = Color(0xFFF57C00)
private val MethodBadgeColor = Color(0xFFD32F2F)

@Composable
fun CodeEditorScreen(viewModel: MainViewModel, onBack: (Boolean) -> Unit) {
    val state by viewModel.editor.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    var showExitDialog by remember { mutableStateOf(false) }
    var showNavigationDialog by remember { mutableStateOf(false) }
    var fieldValue by remember { mutableStateOf(TextFieldValue("")) }
    val sharedScrollState = rememberScrollState()

    val visualTransformation = remember(state.file?.name) {
        SyntaxHighlighter.createVisualTransformation(state.file?.name)
    }

    val navSymbols = remember(fieldValue.text, state.file?.name) {
        SyntaxHighlighter.parseNavigationSymbols(fieldValue.text, state.file?.name)
    }

    LaunchedEffect(state.file, state.content, state.isLoading) {
        if (!state.isLoading && state.error == null && fieldValue.text != state.content) {
            fieldValue = TextFieldValue(
                text = state.content,
                selection = TextRange(state.cursor.coerceIn(0, state.content.length))
            )
        }
    }

    BackHandler {
        if (state.isDirty) {
            showExitDialog = true
        } else {
            onBack(state.hasSavedChangesInSession)
        }
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text(stringResource(R.string.unsaved_changes)) },
            text = { Text(stringResource(R.string.save_changes_before_leaving)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.updateContent(fieldValue.text)
                    viewModel.saveFile { saved, _ ->
                        if (saved) {
                            Toast.makeText(context, context.getString(R.string.saved_successfully), Toast.LENGTH_SHORT).show()
                            showExitDialog = false
                            onBack(true)
                        }
                    }
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        showExitDialog = false
                        viewModel.discardAndClose()
                        onBack(false)
                    }) { Text(stringResource(R.string.discard)) }
                    TextButton(onClick = { showExitDialog = false }) { Text(stringResource(R.string.cancel_titlecase)) }
                }
            }
        )
    }

    if (showNavigationDialog) {
        CodeNavigationDialog(
            symbols = navSymbols,
            onDismiss = { showNavigationDialog = false },
            onSelectSymbol = { symbol ->
                showNavigationDialog = false
                val targetCursor = symbol.charOffset.coerceIn(0, fieldValue.text.length)
                fieldValue = fieldValue.copy(selection = TextRange(targetCursor))
                viewModel.updateCursor(targetCursor)
                scope.launch {
                    val linePx = with(density) { ((symbol.startLine - 1).coerceAtLeast(0) * 20).dp.toPx().toInt() }
                    sharedScrollState.animateScrollTo(linePx)
                }
            }
        )
    }

    val cursorLine = remember(fieldValue.text, fieldValue.selection.start) {
        val safeCursor = fieldValue.selection.start.coerceIn(0, fieldValue.text.length)
        fieldValue.text.substring(0, safeCursor).count { it == '\n' } + 1
    }

    val activeSymbolRangeText = remember(cursorLine, navSymbols) {
        val enclosingMethod = navSymbols.firstOrNull {
            it.kind == NavSymbolKind.METHOD && cursorLine in it.startLine..it.endLine
        }
        if (enclosingMethod != null) {
            "[${enclosingMethod.startLine} - ${enclosingMethod.endLine}] : ${enclosingMethod.title}"
        } else {
            "UTF-8"
        }
    }

    Column(Modifier.fillMaxSize().background(EditorWhite)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().background(EditorToolbar).padding(horizontal = 1.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                if (state.isDirty) showExitDialog = true else onBack(state.hasSavedChangesInSession)
            }) {
                Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.back), tint = EditorWhite)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    (if (state.isDirty) "*" else "") + (state.file?.name ?: stringResource(R.string.editor)),
                    color = EditorWhite,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${lineAndColumn(fieldValue.text, fieldValue.selection.start)} $activeSymbolRangeText",
                    color = Color(0xFFD6D6D6),
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = { showNavigationDialog = true }) {
                Icon(Icons.Default.Explore, contentDescription = stringResource(R.string.navigation_title), tint = EditorWhite)
            }
            IconButton(onClick = { viewModel.undo() }) {
                Icon(Icons.Default.Undo, contentDescription = "Undo", tint = EditorWhite)
            }
            IconButton(onClick = { viewModel.redo() }) {
                Icon(Icons.Default.Redo, contentDescription = stringResource(R.string.redo), tint = EditorWhite)
            }
            IconButton(onClick = {
                viewModel.updateContent(fieldValue.text)
                viewModel.saveFile { saved, _ ->
                    if (saved) Toast.makeText(context, context.getString(R.string.saved_successfully), Toast.LENGTH_SHORT).show()
                }
            }) {
                Icon(Icons.Default.Save, contentDescription = stringResource(R.string.save), tint = EditorWhite)
            }
            IconButton(onClick = { Toast.makeText(context, context.getString(R.string.editor_mode), Toast.LENGTH_SHORT).show() }) {
                Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.edit), tint = EditorWhite)
            }
            IconButton(onClick = { Toast.makeText(context, context.getString(R.string.no_additional_editor_actions), Toast.LENGTH_SHORT).show() }) {
                Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.more), tint = EditorWhite)
            }
        }

        if (state.isLoading) {
            Text(stringResource(R.string.loading), Modifier.padding(12.dp), color = Color.Black)
        } else if (state.error != null) {
            Text(state.error.orEmpty(), Modifier.padding(12.dp), color = Color.Red)
        } else {
            val lineCount = fieldValue.text.count { it == '\n' } + 1
            Row(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(sharedScrollState)
            ) {
                Column(
                    Modifier.width(44.dp).background(LineNumberBackground).padding(top = 8.dp, end = 7.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    repeat(lineCount) { line ->
                        val isCurrentLine = (line + 1) == cursorLine
                        Text(
                            text = (line + 1).toString(),
                            color = if (isCurrentLine) Color(0xFF1976D2) else EditorGray,
                            fontWeight = if (isCurrentLine) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp,
                            lineHeight = 20.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                HorizontalDivider(thickness = 1.dp, color = EditorSeparator)
                BasicTextField(
                    value = fieldValue,
                    onValueChange = { value ->
                        fieldValue = value
                        viewModel.updateContent(value.text)
                        viewModel.updateCursor(value.selection.start)
                    },
                    visualTransformation = visualTransformation,
                    modifier = Modifier.weight(1f).padding(start = 8.dp, top = 8.dp, end = 8.dp).height((lineCount * 20 + 24).dp),
                    textStyle = TextStyle(
                        color = Color(0xFF111111),
                        fontSize = 12.sp,
                        lineHeight = 20.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrect = false,
                        keyboardType = KeyboardType.Text
                    )
                )
            }
            Row(
                Modifier.fillMaxWidth().background(EditorToolbar).horizontalScroll(rememberScrollState()).imePadding(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("\t", "{", "}", "(", ")", ";", ".", ":", "\"", "/", "-", "+", "*", "=", "<", ">", "#").forEach { symbol ->
                    TextButton(onClick = {
                        val start = fieldValue.selection.min
                        val end = fieldValue.selection.max
                        val insertText = if (symbol == "\t") "    " else symbol
                        val updated = fieldValue.text.replaceRange(start, end, insertText)
                        val cursor = start + insertText.length
                        fieldValue = TextFieldValue(updated, TextRange(cursor))
                        viewModel.updateContent(updated)
                        viewModel.updateCursor(cursor)
                    }) {
                        Text(if (symbol == "\t") "TAB" else symbol, color = EditorWhite, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun CodeNavigationDialog(
    symbols: List<NavSymbolItem>,
    onDismiss: () -> Unit,
    onSelectSymbol: (NavSymbolItem) -> Unit
) {
    var searchExpanded by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val filtered = remember(symbols, query) {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) symbols else symbols.filter {
            it.title.lowercase(Locale.ROOT).contains(q) ||
                it.subtitle.lowercase(Locale.ROOT).contains(q)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 240.dp, max = 520.dp),
            shape = RoundedCornerShape(4.dp),
            color = Color.White,
            tonalElevation = 4.dp
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (searchExpanded) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF757575), modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = Color(0xFF111111), fontSize = 14.sp),
                            cursorBrush = SolidColor(Color(0xFF1976D2)),
                            modifier = Modifier.weight(1f),
                            decorationBox = { inner ->
                                if (query.isEmpty()) {
                                    Text(stringResource(R.string.search_hint), color = Color(0xFF9E9E9E), fontSize = 13.sp)
                                }
                                inner()
                            }
                        )
                        IconButton(
                            onClick = {
                                query = ""
                                searchExpanded = false
                            },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF555555), modifier = Modifier.size(18.dp))
                        }
                    } else {
                        Text(
                            text = stringResource(R.string.navigation_title),
                            color = Color(0xFF111111),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { searchExpanded = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Search, contentDescription = stringResource(R.string.search_hint), tint = Color(0xFF333333), modifier = Modifier.size(20.dp))
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                HorizontalDivider(thickness = 0.6.dp, color = EditorSeparator)

                if (filtered.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(stringResource(R.string.no_items_found), color = Color(0xFF757575), fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        items(filtered) { item ->
                            val badgeColor = when (item.kind) {
                                NavSymbolKind.CLASS -> ClassBadgeColor
                                NavSymbolKind.FIELD -> FieldBadgeColor
                                NavSymbolKind.METHOD -> MethodBadgeColor
                            }
                            val badgeLetter = when (item.kind) {
                                NavSymbolKind.CLASS -> "C"
                                NavSymbolKind.FIELD -> "F"
                                NavSymbolKind.METHOD -> "M"
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectSymbol(item) }
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(badgeColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = badgeLetter,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        text = item.title,
                                        color = Color(0xFF111111),
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (item.subtitle.isNotEmpty()) {
                                        Text(
                                            text = item.subtitle,
                                            color = Color(0xFF757575),
                                            fontSize = 11.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Text(
                                    text = ":${item.startLine}",
                                    color = Color(0xFF757575),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            HorizontalDivider(thickness = 0.5.dp, color = EditorSeparator)
                        }
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text(stringResource(R.string.close), color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun lineAndColumn(text: String, cursor: Int): String {
    val safeCursor = cursor.coerceIn(0, text.length)
    val beforeCursor = text.substring(0, safeCursor)
    val line = beforeCursor.count { it == '\n' } + 1
    val column = safeCursor - beforeCursor.lastIndexOf('\n')
    return "$line:$column"
}
