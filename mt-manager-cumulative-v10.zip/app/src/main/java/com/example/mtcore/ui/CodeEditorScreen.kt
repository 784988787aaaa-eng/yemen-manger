package com.example.mtcore.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.example.mtcore.R
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val EditorToolbar = Color(0xFF2B2B2B)
private val EditorWhite = Color.White
private val LineNumberBackground = Color(0xFFF5F5F5)
private val EditorGray = Color(0xFF757575)
private val EditorSeparator = Color(0xFFE0E0E0)

@Composable
fun CodeEditorScreen(viewModel: MainViewModel, onBack: (Boolean) -> Unit) {
    val state by viewModel.editor.collectAsState()
    val context = LocalContext.current
    var showExitDialog by remember { mutableStateOf(false) }
    var fieldValue by remember { mutableStateOf(TextFieldValue("")) }
    val sharedScrollState = rememberScrollState()

    LaunchedEffect(state.file, state.content, state.isLoading) {
        if (!state.isLoading && state.error == null && fieldValue.text != state.content) {
            fieldValue = TextFieldValue(
                text = state.content,
                selection = TextRange(state.cursor.coerceIn(0, state.content.length))
            )
        }
    }

    BackHandler {
        if (state.isDirty) {
            showExitDialog = true
        } else {
            onBack(state.hasSavedChangesInSession)
        }
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text(stringResource(R.string.unsaved_changes)) },
            text = { Text(stringResource(R.string.save_changes_before_leaving)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.updateContent(fieldValue.text)
                    viewModel.saveFile { saved, _ ->
                        if (saved) {
                            Toast.makeText(context, context.getString(R.string.saved_successfully), Toast.LENGTH_SHORT).show()
                            showExitDialog = false
                            onBack(true)
                        }
                    }
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        showExitDialog = false
                        viewModel.discardAndClose()
                        onBack(false)
                    }) { Text(stringResource(R.string.discard)) }
                    TextButton(onClick = { showExitDialog = false }) { Text(stringResource(R.string.cancel_titlecase)) }
                }
            }
        )
    }

    Column(Modifier.fillMaxSize().background(EditorWhite)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().background(EditorToolbar).padding(horizontal = 1.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                if (state.isDirty) showExitDialog = true else onBack(state.hasSavedChangesInSession)
            }) {
                Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.back), tint = EditorWhite)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    (if (state.isDirty) "*" else "") + (state.file?.name ?: stringResource(R.string.editor)),
                    color = EditorWhite,
                    fontSize = 13.sp,
                    maxLines = 1
                )
                Text("${lineAndColumn(fieldValue.text, fieldValue.selection.start)} UTF-8", color = EditorWhite, fontSize = 10.sp)
            }
            IconButton(onClick = { Toast.makeText(context, context.getString(R.string.pinned_for_session), Toast.LENGTH_SHORT).show() }) {
                Icon(Icons.Default.PushPin, contentDescription = stringResource(R.string.pin), tint = EditorWhite)
            }
            IconButton(onClick = {
                viewModel.undo()
            }) {
                Icon(Icons.Default.Undo, contentDescription = "Undo", tint = EditorWhite)
            }
            IconButton(onClick = {
                viewModel.redo()
            }) {
                Icon(Icons.Default.Redo, contentDescription = stringResource(R.string.redo), tint = EditorWhite)
            }
            IconButton(onClick = {
                viewModel.updateContent(fieldValue.text)
                viewModel.saveFile { saved, _ ->
                    if (saved) Toast.makeText(context, context.getString(R.string.saved_successfully), Toast.LENGTH_SHORT).show()
                }
            }) {
                Icon(Icons.Default.Save, contentDescription = stringResource(R.string.save), tint = EditorWhite)
            }
            IconButton(onClick = { Toast.makeText(context, context.getString(R.string.editor_mode), Toast.LENGTH_SHORT).show() }) {
                Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.edit), tint = EditorWhite)
            }
            IconButton(onClick = { Toast.makeText(context, context.getString(R.string.no_additional_editor_actions), Toast.LENGTH_SHORT).show() }) {
                Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.more), tint = EditorWhite)
            }
        }

        if (state.isLoading) {
            Text(stringResource(R.string.loading), Modifier.padding(12.dp), color = Color.Black)
        } else if (state.error != null) {
            Text(state.error.orEmpty(), Modifier.padding(12.dp), color = Color.Red)
        } else {
            val lineCount = fieldValue.text.count { it == '\n' } + 1
            Row(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(sharedScrollState)
            ) {
                Column(
                    Modifier.width(44.dp).background(LineNumberBackground).padding(top = 8.dp, end = 7.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    repeat(lineCount) { line ->
                        Text(
                            text = (line + 1).toString(),
                            color = EditorGray,
                            fontSize = 12.sp,
                            lineHeight = 20.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                HorizontalDivider(thickness = 1.dp, color = EditorSeparator)
                BasicTextField(
                    value = fieldValue,
                    onValueChange = { value ->
                        fieldValue = value
                        viewModel.updateContent(value.text)
                        viewModel.updateCursor(value.selection.start)
                    },
                    modifier = Modifier.weight(1f).padding(start = 8.dp, top = 8.dp, end = 8.dp).height((lineCount * 20 + 16).dp),
                    textStyle = TextStyle(
                        color = Color(0xFF111111),
                        fontSize = 12.sp,
                        lineHeight = 20.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrect = false,
                        keyboardType = KeyboardType.Text
                    )
                )
            }
            Row(
                Modifier.fillMaxWidth().background(EditorToolbar).horizontalScroll(rememberScrollState()).imePadding(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("/", "-", "+", "*", "=", "<", ">").forEach { symbol ->
                    TextButton(onClick = {
                        val start = fieldValue.selection.min
                        val end = fieldValue.selection.max
                        val updated = fieldValue.text.replaceRange(start, end, symbol)
                        val cursor = start + symbol.length
                        fieldValue = TextFieldValue(updated, TextRange(cursor))
                        viewModel.updateContent(updated)
                        viewModel.updateCursor(cursor)
                    }) {
                        Text(symbol, color = EditorWhite, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

private fun lineAndColumn(text: String, cursor: Int): String {
    val safeCursor = cursor.coerceIn(0, text.length)
    val beforeCursor = text.substring(0, safeCursor)
    val line = beforeCursor.count { it == '\n' } + 1
    val column = safeCursor - beforeCursor.lastIndexOf('\n')
    return "$line:$column"
}
