package com.example.mtcore

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mtcore.ui.CodeEditorScreen
import com.example.mtcore.ui.FileExplorerScreen
import com.example.mtcore.ui.InstalledAppsScreen
import com.example.mtcore.ui.MainViewModel
import com.example.mtcore.ui.theme.MTCoreTheme
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val mainViewModel: MainViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return MainViewModel(cacheDir) as T
            }
        }
    }

    private var permissionGranted by mutableStateOf(false)
    private var languageCode by mutableStateOf("en")

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val nowGranted = hasPermission()
        if (!permissionGranted && nowGranted) mainViewModel.refreshAll()
        permissionGranted = nowGranted
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionGranted = hasPermission()
        setContent {
            val localizedContext = localizedContext(this, languageCode)
            val direction = if (languageCode == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
            CompositionLocalProvider(
                LocalContext provides localizedContext,
                LocalLayoutDirection provides direction
            ) {
                MTCoreTheme {
                    Surface(Modifier.fillMaxSize()) {
                        MainApp(
                            permissionGranted = permissionGranted,
                            requestPermission = { requestPermission() },
                            viewModel = mainViewModel,
                            languageCode = languageCode,
                            onToggleLanguage = { languageCode = if (languageCode == "en") "ar" else "en" }
                        )
                    }
                }
            }
        }
        if (!permissionGranted) requestPermission()
    }

    override fun onResume() {
        super.onResume()
        val previouslyGranted = permissionGranted
        val currentlyGranted = hasPermission()
        permissionGranted = currentlyGranted
        if (!previouslyGranted && currentlyGranted) mainViewModel.refreshAll()
    }

    private fun hasPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }
    }
}

private fun localizedContext(base: Context, languageCode: String): Context {
    val configuration = Configuration(base.resources.configuration)
    configuration.setLocale(Locale(languageCode))
    configuration.setLayoutDirection(Locale(languageCode))
    return base.createConfigurationContext(configuration)
}

@Composable
private fun MainApp(
    permissionGranted: Boolean,
    requestPermission: () -> Unit,
    viewModel: MainViewModel,
    languageCode: String,
    onToggleLanguage: () -> Unit
) {
    val editor by viewModel.editor.collectAsStateWithLifecycle()
    var currentFile by remember { mutableStateOf<File?>(null) }
    var showInstalledApps by remember { mutableStateOf(false) }
    var pendingArchiveFile by remember { mutableStateOf<File?>(null) }
    var showArchiveInfo by remember { mutableStateOf(false) }
    val context = LocalContext.current

    if (!permissionGranted) {
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(if (languageCode == "ar") "امنح إذن الوصول إلى الملفات للمتابعة" else "Grant file access to continue")
            Button(onClick = requestPermission) {
                Text(if (languageCode == "ar") "منح الإذن" else "Grant access")
            }
        }
        return
    }

    when {
        currentFile != null -> {
            CodeEditorScreen(viewModel) { wasSaved ->
                val editedFile = editor.file
                if (wasSaved && editedFile != null && viewModel.archiveFor(editedFile) != null) {
                    pendingArchiveFile = editedFile
                    showArchiveInfo = true
                }
                currentFile = null
            }
        }
        showInstalledApps -> {
            InstalledAppsScreen(
                viewModel = viewModel,
                onBack = { showInstalledApps = false },
                onLocateExtractedApk = { extractedFile ->
                    showInstalledApps = false
                    viewModel.locateExtractedFile(extractedFile)
                }
            )
        }
        else -> {
            FileExplorerScreen(
                viewModel = viewModel,
                onOpenFile = { file ->
                    currentFile = file
                    viewModel.openFile(file)
                },
                onToggleLanguage = onToggleLanguage,
                languageCode = languageCode,
                onOpenInstalledApps = { showInstalledApps = true }
            )
        }
    }

    if (showArchiveInfo && pendingArchiveFile != null) {
        val fileName = pendingArchiveFile!!.name
        val prompt = if (languageCode == "ar") {
            "تم تعديل الملف \"$fileName\". هل تريد تحديث الأرشيف؟"
        } else {
            "File \"$fileName\" has been modified. Do you want to update it?"
        }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = {
                showArchiveInfo = false
                pendingArchiveFile = null
            },
            title = { Text("Info") },
            text = { Text(prompt) },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    val file = pendingArchiveFile!!
                    viewModel.updateArchive(file) { success, error ->
                        android.widget.Toast.makeText(
                            context,
                            if (success) "Archive updated successfully" else error.orEmpty(),
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                    showArchiveInfo = false
                    pendingArchiveFile = null
                }) { Text(if (languageCode == "ar") "موافق" else "OK") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = {
                    showArchiveInfo = false
                    pendingArchiveFile = null
                }) { Text(if (languageCode == "ar") "إلغاء" else "CANCEL") }
            }
        )
    }
}
