package com.example.mtcore.ui

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.mtcore.R
import com.example.mtcore.data.CompressionLevel
import com.example.mtcore.data.FileProperties
import java.io.File

private val DialogBlue = Color(0xFF1976D2)
private val DialogBlack = Color(0xFF111111)

@Composable
private fun CompactDialog(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit,
    actions: @Composable () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().widthIn(max = 380.dp),
            shape = RoundedCornerShape(4.dp),
            color = Color.White,
            tonalElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title, color = DialogBlack, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                content()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    actions()
                }
            }
        }
    }
}

@Composable
fun CreateDialog(onDismiss: () -> Unit, onCreateFile: (String) -> Unit, onCreateFolder: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val enterNameError = stringResource(R.string.enter_name)
    CompactDialog(stringResource(R.string.create_file_title), onDismiss, content = {
        Column {
            UnderlinedField(value = name, onValueChange = { name = it; error = null }, hint = stringResource(R.string.name))
            error?.let { Text(it, color = Color.Red, fontSize = 12.sp) }
        }
    }, actions = {
        TextButton(onClick = { if (name.isBlank()) error = enterNameError else onCreateFile(name) }) { Text(stringResource(R.string.file_label), color = DialogBlue) }
        TextButton(onClick = { if (name.isBlank()) error = enterNameError else onCreateFolder(name) }) { Text(stringResource(R.string.folder_label), color = DialogBlue) }
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = DialogBlue) }
    })
}

@Composable
fun JumpDialog(initialPath: String, onDismiss: () -> Unit, onJump: (String) -> Unit) {
    val context = LocalContext.current
    var path by remember(initialPath) { mutableStateOf(TextFieldValue(initialPath, TextRange(0, initialPath.length))) }
    CompactDialog(stringResource(R.string.jump_to_path), onDismiss, content = {
        UnderlinedTextField(value = path, onValueChange = { path = it }, hint = stringResource(R.string.path))
    }, actions = {
        TextButton(onClick = { val clip = readClipboard(context); path = TextFieldValue(clip, TextRange(0, clip.length)) }) { Text(stringResource(R.string.paste), color = DialogBlue) }
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = DialogBlue) }
        TextButton(onClick = { onJump(path.text) }) { Text(stringResource(R.string.ok), color = DialogBlue) }
    })
}

@Composable
fun RenameDialog(initialName: String, onDismiss: () -> Unit, onRename: (String) -> Unit) {
    val context = LocalContext.current
    var name by remember(initialName) { mutableStateOf(TextFieldValue(initialName, TextRange(0, initialName.length))) }
    CompactDialog(stringResource(R.string.rename), onDismiss, content = {
        UnderlinedTextField(value = name, onValueChange = { name = it }, hint = stringResource(R.string.filename))
    }, actions = {
        TextButton(onClick = { val clip = readClipboard(context); name = TextFieldValue(clip, TextRange(0, clip.length)) }) { Text(stringResource(R.string.paste), color = DialogBlue) }
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = DialogBlue) }
        TextButton(onClick = { onRename(name.text) }) { Text(stringResource(R.string.ok), color = DialogBlue) }
    })
}

@Composable
fun PropertiesDialog(properties: FileProperties, onDismiss: () -> Unit) {
    CompactDialog(stringResource(R.string.properties_title), onDismiss, content = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.path_value, properties.path), color = DialogBlack, fontSize = 12.sp)
            Text(stringResource(R.string.size_value, properties.size), color = DialogBlack, fontSize = 13.sp)
            Text(stringResource(R.string.modified_value, properties.modified), color = DialogBlack, fontSize = 13.sp)
            Text(stringResource(R.string.readable_value, properties.readable), color = DialogBlack, fontSize = 13.sp)
            Text(stringResource(R.string.writable_value, properties.writable), color = DialogBlack, fontSize = 13.sp)
        }
    }, actions = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.ok), color = DialogBlue) } })
}

enum class ConflictChoice { REPLACE, SKIP, KEEP_BOTH }

@Composable
fun ConflictDialog(source: File, destination: File, onChoice: (ConflictChoice) -> Unit, onDismiss: () -> Unit) {
    var choice by remember(source.absolutePath, destination.absolutePath) { mutableStateOf(ConflictChoice.REPLACE) }
    CompactDialog(stringResource(R.string.file_conflict), onDismiss, content = {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(stringResource(R.string.source_name, source.name), color = DialogBlack, fontSize = 13.sp)
            Text(stringResource(R.string.source_stats, formatFileDate(source), formatFileSize(source.length())), color = Color.Gray, fontSize = 11.sp)
            Text(stringResource(R.string.destination_name, destination.name), color = DialogBlack, fontSize = 13.sp)
            Text(stringResource(R.string.source_stats, formatFileDate(destination), formatFileSize(destination.length())), color = Color.Gray, fontSize = 11.sp)
            listOf(ConflictChoice.REPLACE to stringResource(R.string.replace_destination), ConflictChoice.SKIP to stringResource(R.string.skip_item), ConflictChoice.KEEP_BOTH to stringResource(R.string.keep_both)).forEach { (option, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = choice == option, onClick = { choice = option })
                    Text(label, color = DialogBlack, fontSize = 13.sp)
                }
            }
        }
    }, actions = {
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = DialogBlue) }
        TextButton(onClick = { onChoice(choice) }) { Text(stringResource(R.string.continue_label), color = DialogBlue) }
    })
}

@Composable
fun CreateArchiveDialog(initialName: String, onDismiss: () -> Unit, onCreate: (String, CompressionLevel, Boolean) -> Unit) {
    var filename by remember(initialName) { mutableStateOf(initialName) }
    var level by remember { mutableStateOf(CompressionLevel.NORMAL) }
    var expanded by remember { mutableStateOf(false) }
    var deleteSource by remember { mutableStateOf(false) }
    CompactDialog(stringResource(R.string.create_archive_title), onDismiss, content = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.filename), color = DialogBlack, fontSize = 13.sp)
            UnderlinedField(value = filename, onValueChange = { filename = it }, hint = stringResource(R.string.filename))
            Text(stringResource(R.string.level), color = DialogBlack, fontSize = 13.sp)
            Button(onClick = { expanded = true }, colors = ButtonDefaults.buttonColors(containerColor = DialogBlue)) { Text(stringResource(level.labelRes()), fontSize = 13.sp) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                CompressionLevel.entries.forEach { option -> DropdownMenuItem(text = { Text(stringResource(option.labelRes())) }, onClick = { level = option; expanded = false }) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.delete_source_after_compression), modifier = Modifier.weight(1f), color = DialogBlack, fontSize = 12.sp)
                Switch(checked = deleteSource, onCheckedChange = { deleteSource = it })
            }
        }
    }, actions = {
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = DialogBlue) }
        TextButton(onClick = { onCreate(filename, level, deleteSource) }) { Text(stringResource(R.string.ok), color = DialogBlue) }
    })
}

@Composable
fun AddToZipDialog(archive: File, item: File, onDismiss: () -> Unit, onAdd: (String, CompressionLevel, Boolean) -> Unit) {
    var entryName by remember(item.absolutePath) { mutableStateOf(item.name) }
    var level by remember { mutableStateOf(CompressionLevel.NORMAL) }
    var expanded by remember { mutableStateOf(false) }
    var deleteSource by remember { mutableStateOf(false) }
    CompactDialog(stringResource(R.string.add_to_zip), onDismiss, content = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.archive_name, archive.name), color = DialogBlack, fontSize = 12.sp)
            Text(stringResource(R.string.rename_entry), color = DialogBlack, fontSize = 13.sp)
            UnderlinedField(value = entryName, onValueChange = { entryName = it }, hint = item.name)
            Text(stringResource(R.string.level), color = DialogBlack, fontSize = 13.sp)
            Button(onClick = { expanded = true }, colors = ButtonDefaults.buttonColors(containerColor = DialogBlue)) { Text(stringResource(level.labelRes()), fontSize = 13.sp) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                CompressionLevel.entries.forEach { option -> DropdownMenuItem(text = { Text(stringResource(option.labelRes())) }, onClick = { level = option; expanded = false }) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.delete_source_after_add), modifier = Modifier.weight(1f), color = DialogBlack, fontSize = 12.sp)
                Switch(checked = deleteSource, onCheckedChange = { deleteSource = it })
            }
        }
    }, actions = {
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = DialogBlue) }
        TextButton(onClick = { if (entryName.isNotBlank() && !entryName.contains("/") && !entryName.contains("\\")) onAdd(entryName, level, deleteSource) }) { Text(stringResource(R.string.add), color = DialogBlue) }
    })
}

@Composable
private fun UnderlinedTextField(value: TextFieldValue, onValueChange: (TextFieldValue) -> Unit, hint: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            textStyle = TextStyle(color = DialogBlack, fontSize = 14.sp),
            decorationBox = { innerTextField ->
                Column {
                    if (value.text.isEmpty()) Text(hint, color = Color.Gray, fontSize = 13.sp)
                    innerTextField()
                    HorizontalDivider(thickness = 1.dp, color = Color(0xFF2196F3))
                }
            }
        )
    }
}

@Composable
private fun UnderlinedField(value: String, onValueChange: (String) -> Unit, hint: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            textStyle = TextStyle(color = DialogBlack, fontSize = 14.sp),
            decorationBox = { innerTextField ->
                Column {
                    if (value.isEmpty()) Text(hint, color = Color.Gray, fontSize = 13.sp)
                    innerTextField()
                    HorizontalDivider(thickness = 1.dp, color = Color(0xFF2196F3))
                }
            }
        )
    }
}

private fun readClipboard(context: Context): String {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    return manager.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
}

private fun formatFileDate(file: File): String = java.text.SimpleDateFormat("yy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date(file.lastModified()))

private fun formatFileSize(bytes: Long): String {
    var size = bytes.toDouble()
    val units = arrayOf("B", "KB", "MB", "GB")
    var index = 0
    while (size >= 1024 && index < units.lastIndex) { size /= 1024; index += 1 }
    return if (index == 0) "${size.toLong()}${units[index]}" else String.format(java.util.Locale.US, "%.2f%s", size, units[index])
}

private fun CompressionLevel.labelRes(): Int = when (this) {
    CompressionLevel.STORE -> R.string.store
    CompressionLevel.FAST -> R.string.fast
    CompressionLevel.NORMAL -> R.string.normal
    CompressionLevel.MAXIMUM -> R.string.maximum
    CompressionLevel.ULTRA -> R.string.ultra
}
